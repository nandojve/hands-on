/*
 * HandsOn.c
 *
 * Created: 03/06/2014 09:09:38
 *  Author: nando
 */ 

#include <sysclk.h>
#include <delay.h>
#include <ioport.h>
#include "conf_board.h"

int main(void)
{
	irq_initialize_vectors();
	sysclk_init();
	board_init();
	
	for(;;)
	{
		ioport_set_pin_level(LED0, IOPORT_PIN_LEVEL_HIGH);
		delay_ms(250);
		ioport_set_pin_level(LED0, IOPORT_PIN_LEVEL_LOW);
		delay_ms(250);
	}
}